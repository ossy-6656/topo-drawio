<?xml version="1.0" encoding="GBK"?>
<sgd p_HasSensitiveRegion="0" state="2" p_AlignCenter="8,6" >
    <Disconnector id="EN_����С��_������" >
        <Layer w="16" x="0" y="0" h="14" id="0" >
            <polyline fm="0" p_Plane="0" id="0" p_EndArrowType="0" p_AssFlag="128" lc="170,170,255" p_ShowModeMask="3" sta="0" switchapp="1" p_RoundBox="2,3,11,6" p_DyColorFlag="0" p_LevelEnd="0" p_NameString="" p_LevelStart="0" af="2147483647" d="2.9,8.89 7.88,3.9 12.89,8.89" fc="0,255,0" tfr="rotate(0)" ls="1" p_StartArrowType="0" lw="1" p_StartArrowSize="4" p_EndArrowSize="4" />
            <polyline fm="0" p_Plane="0" id="0" p_EndArrowType="0" p_AssFlag="128" lc="170,170,255" p_ShowModeMask="3" sta="0" switchapp="1" p_RoundBox="2,6,11,6" p_DyColorFlag="0" p_LevelEnd="0" p_NameString="" p_LevelStart="0" af="2147483647" d="2.9,11.89 7.88,6.9 12.89,11.89" fc="0,255,0" tfr="rotate(0)" ls="1" p_StartArrowType="0" lw="1" p_StartArrowSize="4" p_EndArrowSize="4" />
            <polyline fm="0" p_Plane="0" id="6000000" p_EndArrowType="0" p_AssFlag="128" lc="170,170,255" p_ShowModeMask="3" sta="1" switchapp="1" p_RoundBox="1,3,13,8" p_DyColorFlag="0" p_LevelEnd="1" p_NameString="" p_LevelStart="1" af="2147483647" d="2.9,9.89 7.88,4.9 12.89,9.89" fc="0,255,0" tfr="rotate(0)" ls="1" p_StartArrowType="0" lw="3" p_StartArrowSize="4" p_EndArrowSize="4" />
            <pin fm="0" cx="8" cy="4" r="2" p_Plane="0" id="18000000" p_AssFlag="128" lc="255,0,0" p_ShowModeMask="3" sta="0" switchapp="1" p_RoundBox="5,1,5,5" p_DyColorFlag="0" p_LevelEnd="0" p_NameString="" index="0" p_LevelStart="0" af="39231" fc="0,255,0" tfr="rotate(0)" ls="1" lw="1" />
            <pin fm="0" cx="8" cy="7" r="2" p_Plane="0" id="18000000" p_AssFlag="128" lc="255,0,0" p_ShowModeMask="3" sta="0" switchapp="1" p_RoundBox="5,4,5,5" p_DyColorFlag="0" p_LevelEnd="0" p_NameString="" index="1" p_LevelStart="0" af="39231" fc="0,255,0" tfr="rotate(0)" ls="1" lw="1" />
        </Layer>
        <Layer w="16" x="0" y="0" h="14" id="0" />
        <Layer w="16" x="0" y="0" h="14" id="0" />
    </Disconnector>
</sgd>
