<?xml version="1.0" encoding="GBK"?>
<sgd p_HasSensitiveRegion="0" state="2" p_AlignCenter="12,8" >
    <Disconnector id="EN_���뿪��_����" >
        <Layer w="24" x="0" y="0" h="12" id="0" >
            <line fm="0" p_Plane="0" id="1000005" x1="6" x2="19" p_EndArrowType="0" p_AssFlag="128" lc="0,0,255" p_ShowModeMask="3" sta="0" switchapp="1" p_RoundBox="5,1,14,7" p_DyColorFlag="1" p_LevelEnd="0" p_NameString="" y1="8" y2="2" p_LevelStart="0" af="36895" d="6,8 19,2" fc="0,255,0" tfr="rotate(0)" ls="1" p_StartArrowType="0" lw="1" p_StartArrowSize="4" p_EndArrowSize="4" />
            <circle fm="0" cx="20" cy="8" r="2" p_Plane="0" id="3000006" p_AssFlag="128" lc="0,0,255" p_ShowModeMask="3" sta="0" switchapp="1" p_RoundBox="17,5,5,5" p_DyColorFlag="14" p_LevelEnd="0" p_NameString="" p_LevelStart="0" af="36895" fc="0,255,0" tfr="rotate(0)" ls="1" lw="1" />
            <circle fm="0" cx="4" cy="8" r="2" p_Plane="0" id="3000007" p_AssFlag="128" lc="0,0,255" p_ShowModeMask="3" sta="0" switchapp="1" p_RoundBox="1,5,5,5" p_DyColorFlag="0" p_LevelEnd="0" p_NameString="" p_LevelStart="0" af="36895" fc="0,255,0" tfr="rotate(0)" ls="1" lw="1" />
            <circle fm="0" cx="4" cy="8" r="2" p_Plane="0" id="3000007" p_AssFlag="128" lc="0,0,255" p_ShowModeMask="3" sta="1" switchapp="1" p_RoundBox="1,5,5,5" p_DyColorFlag="0" p_LevelEnd="1" p_NameString="" p_LevelStart="1" af="36895" fc="0,255,0" tfr="rotate(0)" ls="1" lw="1" />
            <circle fm="0" cx="20" cy="8" r="2" p_Plane="0" id="3000006" p_AssFlag="128" lc="0,0,255" p_ShowModeMask="3" sta="1" switchapp="1" p_RoundBox="17,5,5,5" p_DyColorFlag="14" p_LevelEnd="1" p_NameString="" p_LevelStart="1" af="36895" fc="0,255,0" tfr="rotate(0)" ls="1" lw="1" />
            <line fm="0" p_Plane="0" id="1000005" x1="6" x2="18" p_EndArrowType="0" p_AssFlag="128" lc="0,0,255" p_ShowModeMask="3" sta="1" switchapp="1" p_RoundBox="5,7,13,1" p_DyColorFlag="1" p_LevelEnd="1" p_NameString="" y1="8" y2="8" p_LevelStart="1" af="36895" d="6,8 18,8" fc="0,255,0" tfr="rotate(0)" ls="1" p_StartArrowType="0" lw="1" p_StartArrowSize="4" p_EndArrowSize="4" />
            <pin fm="0" cx="4" cy="8" r="2" p_Plane="0" id="18000000" p_AssFlag="128" lc="255,0,0" p_ShowModeMask="3" sta="0" switchapp="1" p_RoundBox="1,5,5,5" p_DyColorFlag="0" p_LevelEnd="0" p_NameString="" index="0" p_LevelStart="0" af="39231" fc="0,255,0" tfr="rotate(0)" ls="1" lw="1" />
            <pin fm="0" cx="20" cy="8" r="2" p_Plane="0" id="18000001" p_AssFlag="128" lc="255,0,0" p_ShowModeMask="3" sta="0" switchapp="1" p_RoundBox="17,5,5,5" p_DyColorFlag="0" p_LevelEnd="0" p_NameString="" index="1" p_LevelStart="0" af="39231" fc="0,255,0" tfr="rotate(0)" ls="1" lw="1" />
        </Layer>
        <Layer w="24" x="0" y="0" h="12" id="0" />
    </Disconnector>
</sgd>
