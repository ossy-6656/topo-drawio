<?xml version="1.0" encoding="GBK"?>
<G>
    <Disconnector w="14" h="28" HasSensitiveRegion="0" AlignCenter="4,14" id="EN_NY_��բ��" state="2" >
        <Layer>
            <circle cx="4" fm="0" cy="24" r="2" id="0" LevelStart="1" p_AssFlag="128" lc="0,0,255" p_ShowModeMask="3" sta="1" switchapp="1" p_DyColorFlag="0" p_NameString="" af="39039" tfr="rotate(0)" fc="0,255,0" LevelEnd="1" ls="1" lw="1" />
            <circle cx="4" fm="0" cy="24" r="2" id="0" LevelStart="0" p_AssFlag="128" lc="0,0,255" p_ShowModeMask="3" sta="0" switchapp="1" p_DyColorFlag="0" p_NameString="" af="39039" tfr="rotate(0)" fc="0,255,0" LevelEnd="0" ls="1" lw="1" />
            <pin fm="0" cx="4" cy="4" r="2" id="0" LevelStart="0" p_AssFlag="128" lc="255,0,0" p_ShowModeMask="3" sta="0" switchapp="1" p_DyColorFlag="0" p_NameString="" index="0" af="39039" tfr="rotate(0)" fc="0,255,0" LevelEnd="0" ls="1" lw="1" />
            <pin fm="0" cx="4" cy="24" r="2" id="0" LevelStart="0" p_AssFlag="128" lc="255,0,0" p_ShowModeMask="3" sta="0" switchapp="1" p_DyColorFlag="0" p_NameString="" index="1" af="39039" tfr="rotate(0)" fc="0,255,0" LevelEnd="0" ls="1" lw="1" />
            <circle cx="4" fm="0" cy="4" r="1" id="3000000" LevelStart="0" p_AssFlag="128" lc="140,140,140" p_ShowModeMask="3" sta="0" switchapp="1" p_DyColorFlag="0" p_NameString="" af="39039" tfr="rotate(0)" fc="0,255,0" LevelEnd="0" ls="1" lw="1" />
            <circle cx="4" fm="0" cy="24" r="1" id="3000001" LevelStart="0" p_AssFlag="128" lc="140,140,140" p_ShowModeMask="3" sta="0" switchapp="1" p_DyColorFlag="0" p_NameString="" af="39039" tfr="rotate(0)" fc="0,255,0" LevelEnd="0" ls="1" lw="1" />
            <circle cx="4" fm="0" cy="4" r="1" id="3000003" LevelStart="1" p_AssFlag="128" lc="140,140,140" p_ShowModeMask="3" sta="1" switchapp="1" p_DyColorFlag="0" p_NameString="" af="39039" tfr="rotate(0)" fc="0,255,0" LevelEnd="1" ls="1" lw="1" />
            <circle cx="4" fm="0" cy="24" r="1" id="3000004" LevelStart="1" p_AssFlag="128" lc="140,140,140" p_ShowModeMask="3" sta="1" switchapp="1" p_DyColorFlag="0" p_NameString="" af="39039" tfr="rotate(0)" fc="0,255,0" LevelEnd="1" ls="1" lw="1" />
            <line fm="0" id="1000000" LevelStart="1" StartArrowType="0" x1="4" x2="4" StartArrowSize="4" p_AssFlag="128" lc="140,140,140" EndArrowSize="4" p_ShowModeMask="3" sta="1" switchapp="1" p_DyColorFlag="0" p_NameString="" EndArrowType="0" y1="6" y2="22" af="39039" d="4,6 4,22" tfr="rotate(0)" fc="0,255,0" LevelEnd="1" ls="1" lw="1" />
            <line fm="0" id="1000001" LevelStart="0" StartArrowType="0" x1="4" x2="12" StartArrowSize="4" p_AssFlag="128" lc="140,140,140" EndArrowSize="4" p_ShowModeMask="3" sta="0" switchapp="1" p_DyColorFlag="0" p_NameString="" EndArrowType="0" y1="5" y2="20" af="39039" d="4,5 12,20" tfr="rotate(0)" fc="0,255,0" LevelEnd="0" ls="1" lw="1" />
        </Layer>
        <Layer/>
        <Layer/>
        <Layer/>
        <Layer/>
        <Layer/>
        <Layer/>
        <Layer/>
    </Disconnector>
</G>
